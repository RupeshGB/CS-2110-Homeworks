/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=24x32 PC PC.png 
 * Time-stamp: Friday 04/09/2021, 04:40:50
 * 
 * Image Information
 * -----------------
 * PC.png 24@32
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PC_H
#define PC_H

extern const unsigned short PC[768];
#define PC_SIZE 1536
#define PC_LENGTH 768
#define PC_WIDTH 24
#define PC_HEIGHT 32

#endif

