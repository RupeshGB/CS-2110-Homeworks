/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=70x30 RAM RAM.png 
 * Time-stamp: Friday 04/09/2021, 04:42:23
 * 
 * Image Information
 * -----------------
 * RAM.png 70@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RAM_H
#define RAM_H

extern const unsigned short RAM[2100];
#define RAM_SIZE 4200
#define RAM_LENGTH 2100
#define RAM_WIDTH 70
#define RAM_HEIGHT 30

#endif

